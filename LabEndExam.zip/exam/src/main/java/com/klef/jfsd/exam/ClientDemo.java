package com.klef.jfsd.exam;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class ClientDemo {
    public static void main(String[] args) {
        // Configure and build the SessionFactory
        Configuration cfg = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Department.class);
        SessionFactory sessionFactory = cfg.buildSessionFactory();

        try (Session session = sessionFactory.openSession()) {
            // Insert operations
            insertDepartment(session, "IT", "Building A", "Dr. Alice", 50, 2000000.0);
            insertDepartment(session, "HR", "Building B", "Dr. Bob", 20, 500000.0);

            // Delete operation
            deleteDepartmentById(session, 1L); // Example: Delete department with ID 1
        }

        sessionFactory.close();
    }

    // Insert method using persistent object
    private static void insertDepartment(Session session, String name, String location, String hodName, Integer employeeCount, Double annualBudget) {
        Transaction transaction = session.beginTransaction();

        Department department = new Department();
        department.setName(name);
        department.setLocation(location);
        department.setHodName(hodName);
        department.setEmployeeCount(employeeCount);
        department.setAnnualBudget(annualBudget);

        session.save(department);

        transaction.commit();
        System.out.println("Department inserted successfully: " + department);
    }

    // Delete method using HQL with positional parameter
    private static void deleteDepartmentById(Session session, Long deptId) {
        Transaction transaction = session.beginTransaction();

        String hql = "DELETE FROM Department WHERE id = ?1";
        int rowsAffected = session.createQuery(hql)
                                  .setParameter(1, deptId)
                                  .executeUpdate();

        transaction.commit();
        System.out.println(rowsAffected + " department(s) deleted.");
    }
}
